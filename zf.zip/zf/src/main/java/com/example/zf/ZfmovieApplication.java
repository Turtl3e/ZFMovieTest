package com.example.zf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZfmovieApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZfmovieApplication.class, args);
	}

}
